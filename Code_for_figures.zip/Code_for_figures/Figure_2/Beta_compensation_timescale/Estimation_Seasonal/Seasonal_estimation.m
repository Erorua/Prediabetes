function Beta_Cell_compensation_timescale_estimation_seasonal


% ============================================================================================
% Description
% ============================================================================================



%%% Author: Aurore Woller

%%% Date: December 2022

%%% Uni: Weizmann institute of Science

%%%Description:estimation of beta cell compensation timescale T_B(in days)

%%% From seasonal glucose peak(data from paper:Tendler et al.-PNAS 2021)

%%% Calculates T_B as a function of delay D

%%% with D is delay between winter solstice and glucose seasonal peak

%%% output: T_B for male and female 






% ============================================================================================
% Estimation
% ============================================================================================



%%% Estimation of T_B for female

dt=40:1:55;


T=365; 

w=2*pi/T;

mut=(3*w/(1))./tan(dt*w); % equation linking delay to beta cell turnover



phif=44.7; % delay in days for female (see Tendler et al. PNAS 2021)

phifl=44.7-0.54; % variability (see Tendler et al. PNAS 2021)

phifh=44.7+0.54; % variability (see Tendler et al. PNAS 2021)



% Mean 

mutmeanf=(3*w/(1))./tan((phif)*w) % mean turnover rate for female

% Variability low

mutvarlf=(3*w/(1))./tan((phifl)*w) % variability

% Variability high

mutvarhf=(3*w/(1))./tan((phifh)*w) % variability




% characteristic time scale

tau=1./mut; % link between timescale and turnover rate

taumeanf=1/mutmeanf % % mean beta cell timescale for female

tauvarlf=1/mutvarlf % variability low

tauvarhf=1/mutvarhf % variability high





figure(2)


plot(dt,(tau),'LineWidth',3,'Color',[0.65,0.65,0.65])

hold on;


errorbar(phif,taumeanf,taumeanf-tauvarlf,tauvarhf-taumeanf,0.54,0.54,'Marker','o','LineWidth',2,'Color',[0 0 1])



hold on;



%%% Estimation of T_B for male

dt=40:1:55;



T=365;

w=2*pi/T;

mut=(3*w/(1))./tan(dt*w);


phim=49.8; % delay in days for male (see Tendler et al. PNAS 2021)

phiml=49.8-0.54; % variability (see Tendler et al. PNAS 2021)

phimh=49.8+0.54;  % variability (see Tendler et al. PNAS 2021)



% Mean 

mutmeanm=(3*w/(1))./tan((phim)*w) % mean turnover rate for female

% Variability low

mutvarlm=(3*w/(1))./tan((phiml)*w) % variability



% Variability high

mutvarhm=(3*w/(1))./tan((phimh)*w) % variability



% characteristic time scale



taumeanm=1/mutmeanm  % mean beta cell timescale for male

tauvarlm=1/mutvarlm % variability low

tauvarhm=1/mutvarhm % variability high







figure(2)




hold on;


errorbar(phim,taumeanm,taumeanm-tauvarlm,tauvarhm-taumeanm,0.54,0.54,'Marker','o','LineWidth',2,'Color',[1 0 0])



hold on;



xlabel('Delay D (days)','FontName','Arial')

ylabel('Compensation timescale T_{beta} (day)','FontName','Arial')

hold on;

set(gca,'FontName','Arial','FontSize',20);

hold on;

legend('Theoretical curve','Female','Male')

 pbaspect([1 1 1])









figure(2)





axes('Position',[.58 .30 .2 .2])
box on

dt=1:1:55;


T=365;

w=2*pi/T;

mut=(-3*w/(1))./tan(pi-dt*w);



% characteristic time scale

tau=1./mut;


plot(dt,tau,'LineWidth',3,'Color',[0.65,0.65,0.65])

hold on;


errorbar(phif,taumeanf,taumeanf-tauvarlf,tauvarhf-taumeanf,0.54,0.54,'Marker','o','LineWidth',2,'Color',[0 0 1])


hold on;


errorbar(phim,taumeanm,taumeanm-tauvarlm,tauvarhm-taumeanm,0.54,0.54,'Marker','o','LineWidth',2,'Color',[1 0 0])



hold on;




hold on;



hold on;



xlabel('Delay D (days)','FontName','Arial')

ylabel('T_{beta} (days)','FontName','Arial')

hold on;

set(gca,'FontName','Arial','FontSize',14);

hold on;





 pbaspect([1 1 1])
 







