function GB_Bifurcation_Si_with_carrying_capacity


clc;


% ============================================================================================
% Description
% ============================================================================================


%%% Author: Aurore Woller

%%% Date: December 2022

%%% Uni: Weizmann institute of Science

%%% Description: Mathematical Model with carrying capacity C

%%% Simulates G vs Si and Beta vs Si

%%% For different ratio T_iR/T_B

%%% with T_IR: timescale of insulin resistance


%%% with T_B: timescale of Beta cell compensation


%%% For Si decreasing exponantially with time as Si=Si0*exp(alpha*t)









% ============================================================================================
% Main
% ============================================================================================



%%% Kinetic param (in h )


u0=48;

Sip=1.5;

C=1.44;

a=7.85;


mu=0.027;


G1=15;

G0=5;

K=1;


th=500;



% slope=1e-03;

slope=0.003;


y0=1.5;


Si0=y0*exp(slope*th);



kine=[u0,C,Sip,a,G0,G1,K,mu,th,slope,y0,Si0];





%%%% Task:

tdyn(kine);




%====================================================================
% Time dynamics
%====================================================================

function tdyn(kine);


%%%% Model with carrying capacity





%%% kinetic parameters
u0=kine(1);
C= kine(2);
Sip=kine(3);
a=kine(4);
G0=kine(5);
G1=kine(6);
K=kine(7);
mu=kine(8);
th=kine(9);
slope=kine(10);
y0=kine(11);
Si0=kine(12);
% 


ratio=[0.01 0.1 1 10 100];




CC = {[0.05,0.39,0.16],[0.14,0.76,0.64],[0.00,1.00,1.00],[0.07,0.62,1.00],[0.00,0.00,1.00]} 





for i=1:1:5

mu=kine(10)*ratio(i)

ratio(i)


kine(8)=mu;




%%%% Initial conditions:



g0=5;


fg0=(g0^2)/((a^2)+(g0^2));

gamma=432;

beta0=(u0/g0-C)*1/((fg0*y0/gamma)); % formula from dI/dt=0


%beta0=30


v=[g0 beta0];


%%%% Time:

trans=20000;
tend=20000;
tstep=0.01;




%%%% Transient Integration:

ttrans = [0:tstep:trans];
tspan = [0:tstep:tend];

option = odeset('RelTol', 1e-5);

if trans > 0 
    
 th=100100; 
 
 kine(9)=th;
    


[t x] = ode45(@dxdt,ttrans,v,option,kine); % transient integration: no HF, no jetlag
v=x(end,:);


end

 th=500; 
 
 kine(9)=th;
    


[t x] = ode45(@dxdt,tspan,v,option,kine);

%  Formula for change in SI

Sip=(y0).*heaviside(th-t)+heaviside(t-th).*((Si0)*exp(-slope*t));




figure(1)



plot(log10(t),Sip,'.','MarkerSize',10,'color',CC{i})


ylabel('Insulin sensitivity (pmol/L.day)-1')

xlabel('Time (days,log10)')


hold on;

hold on;

set(gca,'FontName','Arial','FontSize',16);


pbaspect([1 1 1])

legend('\tau_{IR}=0.1\tau_{B}','\tau_{IR}=0.5\tau_{B}','\tau_{IR}=\tau_{B}','\tau_{IR}=5\tau_{B}','\tau_{IR}=10\tau_{B} current estim.')





figure(2)


plot(Sip,x(:,1),'.','MarkerSize',10,'color',CC{i})

xlabel('Insulin sensitivity (HOMA-IR)-1')

ylabel('Glucose (mmol/L)')


hold on;

set(gca,'FontName','Arial','FontSize',20);

ylim([4 12])

pbaspect([1 1 1])





legend('\tau_{IR}=0.1\tau_{B}','\tau_{IR}=0.5\tau_{B}','\tau_{IR}=\tau_{B}','\tau_{IR}=5\tau_{B}','\tau_{IR}=10\tau_{B} current estim.')




figure(3)


plot(Sip,(x(:,2)),'.','MarkerSize',10,'color',CC{i})




xlabel('Insulin sensitivity (HOMA-IR)-1')

ylabel('Beta cell mass ((\muU/mL).(day-1))')


hold on;

set(gca,'FontName','Arial','FontSize',20);


pbaspect([1 1 1])




legend('\tau_{IR}=0.1\tau_{B}','\tau_{IR}=0.5\tau_{B}','\tau_{IR}=\tau_{B}','\tau_{IR}=5\tau_{B}','\tau_{IR}=10\tau_{B} current estim.')


%ylim([0 6e+05])








end





% ============================================================================================
% dvdt
% ============================================================================================

function dv = dxdt(t,v,kine)


%%% variables

G=v(1);
beta=v(2);


%%% kinetic parameters
u0=kine(1);
C= kine(2);
Sip=kine(3);
a=kine(4);
G0=kine(5);
G1=kine(6);
K=kine(7);
mu=kine(8);
th=kine(9);
slope=kine(10);
y0=kine(11);
Si0=kine(12);

%%% Additional parameters

gamma=432;

K=5e+05; % carrying capacity 



%  Formula for change in SI

Sip=(y0).*heaviside(th-t)+heaviside(t-th).*((Si0)*exp(-slope*t));



 

% Hill function

fg=(G^2)/((a^2)+(G^2));





%%%% equations

dv = [
    u0-((fg*Sip*beta/gamma)+C)*G; % dg/dt
    beta*(mu)*((G/G0)*(1-(beta/K)^1)-1);    % dbeta/dt

] ; 



